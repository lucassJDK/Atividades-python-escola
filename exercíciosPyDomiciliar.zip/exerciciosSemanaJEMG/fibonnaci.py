def gerarSequenciaEmAlcance(elementsNumber:int):
    fibonnaciNumbers:list = [0] * elementsNumber
    fibonnaciNumbers[0] = 1
    fibonnaciNumbers[1] = 1

    for i in range(1,elementsNumber - 1):
        print("repeti")
        fibonnaciNumbers[i + 1] = fibonnaciNumbers[i] + fibonnaciNumbers[i - 1]
    
    for number in fibonnaciNumbers:
        if(number == fibonnaciNumbers[elementsNumber - 1]):
            if(elementsNumber == 2):
                print("1,1")
                return
            print(number)
            return
        print(number,end=",")

elementsNumber:int = int(input("Insira a quantidade de termos que deseja gerar:"))

try:
    gerarSequenciaEmAlcance(elementsNumber)
except IndexError:
     print("Insira uma quantidade válida!") if (elementsNumber <= 0) else print("1")
