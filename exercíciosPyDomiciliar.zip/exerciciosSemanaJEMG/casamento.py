def calcularIdadeMaisFrequenteHomens(listaIdadeCasais:list,idadesHomens:list) -> int:
    contadorColuna:int = 0
    listaFrequencia:list = []
    contadorFrequencia:int = 0

    for idadeCasal in listaIdadeCasais:

        for idadeSeparada in idadeCasal:
            if(contadorColuna % 2 == 0):

                for idadeOutrosCasais in listaIdadeCasais:
                    contadorColunaInterno:int = 0

                    for idadeHomem in idadeOutrosCasais:
                        if(contadorColunaInterno % 2 == 0):
                            if(idadeSeparada == idadeHomem):
                                contadorFrequencia += 1

                        contadorColunaInterno += 1

            contadorColuna += 1
        listaFrequencia.append(contadorFrequencia)
        contadorFrequencia = 0
    return listaIdadeHomens[listaFrequencia.index(max(listaFrequencia))]

def calcularIdadeMaisFrequenteMulheres(listaIdadeCasais:list,idadesMulheres:list) -> int:
    contadorColuna:int = 0
    listaFrequencia:list = []
    contadorFrequencia:int = 0

    for idadeCasal in listaIdadeCasais:

        for idadeSeparada in idadeCasal:
            if(contadorColuna % 2 != 0):

                for idadeOutrosCasais in listaIdadeCasais:
                    contadorColunaInterno:int = 0

                    for idadeMulher in idadeOutrosCasais:
                        if(contadorColunaInterno % 2 != 0):
                            if(idadeSeparada == idadeMulher):
                                contadorFrequencia += 1

                        contadorColunaInterno += 1
            contadorColuna += 1
        listaFrequencia.append(contadorFrequencia)
        contadorFrequencia = 0
    return idadesMulheres[listaFrequencia.index(max(listaFrequencia))]

def calcularIdadeCasalMaisFrequente(listaCasais:list) -> str:
    listaFrequencia:list = []
    contadorFrequencia:int = 0

    for IdadeCasais in listaCasais:
        idadeHomem:int = IdadeCasais[0]
        idadeMulher:int = IdadeCasais[1]

        for idadeOutrosCasais in listaCasais:
              if(idadeHomem == idadeOutrosCasais[0] and idadeMulher == idadeOutrosCasais[1]):
                   contadorFrequencia += 1
        listaFrequencia.append(contadorFrequencia)
        contadorFrequencia = 0
    return str(listaCasais[listaFrequencia.index(max(listaFrequencia))][0]) + " e " + str(listaCasais[listaFrequencia.index(max(listaFrequencia))][1])






listaIdadeCasais:list = []
listaIdadeHomens:list = []
listaIdadeMulheres:list = []
contador:int = 0

while(True):
    contador += 1
    idadeHomem:int = int(input(f"Insira a idade do homem do casal {contador}:"))
    idadeMulher:int = int(input(f"Insira a idade da mulher do casal {contador}:"))

    if(not(idadeHomem >= 18 and idadeHomem <= 30) or not(idadeMulher >= 18 and idadeMulher <= 30)):
        print("idade inválida inserida!")
        break
    listaIdadeHomens.append(idadeHomem)
    listaIdadeMulheres.append(idadeMulher)
    listaIdadeCasais.append([idadeHomem,idadeMulher])
print(" \n \n",end="\n")
print("-" * 80)
print(f" a idade mais frequente de homens é:{calcularIdadeMaisFrequenteHomens(listaIdadeCasais,listaIdadeHomens)} anos \n a idade mais frequente de mulheres é:{calcularIdadeMaisFrequenteMulheres(listaIdadeCasais,listaIdadeMulheres)} anos \n a idade de casal mais frequente é:{calcularIdadeCasalMaisFrequente(listaIdadeCasais)} anos")
print("-" * 80)
print("\n \n")

