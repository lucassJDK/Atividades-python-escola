def calcularDiaIndiceMaior(indices:list) -> int:
    return indices.index(max(indices)) + 1

def calcularDiaIndiceMenor(indices:list) -> int:
    return indices.index(min(indices)) + 1

def calcularMediaPrimeiraQuinzena(indices:list):
    media:float = 0

    for i in range(15):
        media += indices[i]
    return media / 15

def calcularMediaSegundaQuinzena(indices:list) -> int:
    media:float = 0

    for i in range(15,30):
        media += indices[i]
    return media / 15

indices:list = []
for i in range(1,31):
    indice:float = float(input(f"Insira o indice do dia {i} de junho:"))
    indices.append(indice)
print(f"dia que mais choveu: {calcularDiaIndiceMaior(indices)}")
print(f"dia que menos choveu: {calcularDiaIndiceMenor(indices)}")
print(f"media da primeira quinzena: {calcularMediaPrimeiraQuinzena(indices)}")
print(f"media da segunda quinzena: {calcularMediaSegundaQuinzena(indices)}")
    