def calcularAnos(populacao1:int,populacao2:int) -> int:
    anos:int = 0

    while(populacao1 < populacao2):
        populacao1 += populacao1 * 0.03
        populacao2 += populacao2 * 0.02
        anos += 1
    return anos

print(f"irá demorar um total de: {calcularAnos(5_000_000,7_000_000)} anos")
    
