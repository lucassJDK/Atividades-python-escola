def éUmaVogal(char:str) -> bool:
    if(char != "a" and char != "e" and char != "i" and char != "o" and char != "u"):
        return False
        
    return True
def contarVogais(frase:str) -> int:
    chars:list = list(frase)
    numeroDeVogais:int = 0

    for char in chars :
        if(éUmaVogal(char.lower())):
            numeroDeVogais += 1

    return numeroDeVogais

frase:str = input("digite uma frase ou palavra:")
print(f"nesta frase/palavra,existem {contarVogais(frase)} vogais")