def acharNumerosPares(numbers:list):
    count:int = 0

    for number in numbers:
        if(number % 2 == 0):
            print(f"na posição {count} tem o número {number} que é par.")
            count += 1
    
    if(count == 0):
        print("não foi encontrado nenhum número par")

numbers:list = [0] * 10
for i in range(len(numbers)):
    number:int = int(input(f"Digite o número que irá ficar na posição {i}:"))
    numbers[i] = number

acharNumerosPares(numbers)