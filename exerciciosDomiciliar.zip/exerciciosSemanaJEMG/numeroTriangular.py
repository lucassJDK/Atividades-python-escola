def verificarNumTriangular(number:int):
    result:int = 0
    cout:int = 0
    while(True):
        result = (cout) * (cout + 1) * (cout + 2)
        
        if(result == number) : 
            print(f"o número {number} é um número triangular,pois {cout}.{cout + 1}.{cout + 2} = {number}") 
            return

        elif(result > number) : 
            print(f"o número {number} não é triangular")
            return
        cout += 1

userNumber:int = int(input("insira um número:"))

verificarNumTriangular(userNumber)

