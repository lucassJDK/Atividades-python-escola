def lerNumPosicao(vetor:list):
    cout:int = 0

    for numero in vetor:
        print(f"posição[{cout}] tem o número {numero}")
        cout += 1

vetor:list = [0] * 20
lerNumPosicao(vetor)