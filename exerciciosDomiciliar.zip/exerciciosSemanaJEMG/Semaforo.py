def calcularTempoParaAbrir(distancia:float,velocidadeMaxima:float,velocidadeTipica:float) -> float:
    tempo:float = 0
    count:int = 0
    velocidadeAtualDosCarros:float = 0
    tempo += velocidadeMaxima // velocidadeTipica + velocidadeMaxima % velocidadeTipica
    tempo += distancia / (velocidadeMaxima * 3.6)
    return tempo

distancia:float = float(input("Insira a distância até o próximo semáforo:"))
velocidadeMaxima:float = float(input("Insira a velocidade máxima:"))
velocidadeTipica:float = float(input("Insira a aceleração padrão dos carros:"))
print(f"o tempo é:{calcularTempoParaAbrir(distancia,velocidadeMaxima,velocidadeTipica) - 3:.3} segundos")